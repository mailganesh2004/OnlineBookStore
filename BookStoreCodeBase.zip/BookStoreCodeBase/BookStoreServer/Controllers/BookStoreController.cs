﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;

namespace BookStoreServer.Controllers
{
    [RoutePrefix("api/bookstore")]
    public class BookStoreController : ApiController
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [Route("signin")]
        [HttpGet]
        public IHttpActionResult Login()
        {
            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new ByteArrayContent(File.ReadAllBytes(HttpContext.Current.Server.MapPath("~/App_Data/user.json")))
            };

            response.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");
            return ResponseMessage(response);

            //string user = HttpContext.Current.Server.MapPath("~/App_Data/user.json");

            //if (string.IsNullOrEmpty(user))
            //{
            //    return NotFound();
            //}
            //var response = this.Request.CreateResponse(HttpStatusCode.OK);
            //response.Content = new StringContent(user, Encoding.UTF8, "application/json");
            //return ResponseMessage(response);
        }

        [Route("signup")]
        [HttpGet]
        public IHttpActionResult Logout()
        {
            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new ByteArrayContent(File.ReadAllBytes(HttpContext.Current.Server.MapPath("~/App_Data/user.json")))
            };

            response.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");
            return ResponseMessage(response);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [Route("author/find")]
        [HttpGet]
        public IHttpActionResult GetAuthors()
        {
            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new ByteArrayContent(File.ReadAllBytes(HttpContext.Current.Server.MapPath("~/App_Data/authors.json")))
            };

            response.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");
            return ResponseMessage(response);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [Route("bookstore/find")]
        [HttpGet]
        public IHttpActionResult GetBooks()
        {
            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new ByteArrayContent(File.ReadAllBytes(HttpContext.Current.Server.MapPath("~/App_Data/books.json")))
            };

            response.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");
            return ResponseMessage(response);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [Route("category/find")]
        [HttpGet]
        public IHttpActionResult GetCategory()
        {
            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new ByteArrayContent(File.ReadAllBytes(HttpContext.Current.Server.MapPath("~/App_Data/category.json")))
            };

            response.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");
            return ResponseMessage(response);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [Route("publisher/find")]
        [HttpGet]
        public IHttpActionResult GetPublishers()
        {
            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new ByteArrayContent(File.ReadAllBytes(HttpContext.Current.Server.MapPath("~/App_Data/publisher.json")))
            };

            response.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");
            return ResponseMessage(response);
        }
    }
}
