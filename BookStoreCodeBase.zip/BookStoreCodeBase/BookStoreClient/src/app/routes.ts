import { Routes, RouterModule } from '@angular/router';
import { AuthService } from './services';
import { MainComponent, ShowBookComponent, EditBookComponent, HomeComponent, LoginComponent } from './container';

export const routes: Routes = [
    {
        path: '', component: MainComponent, canActivate: [AuthService],
        children: [
            { path: '', component: HomeComponent },
            { path: 'browse', component: ShowBookComponent },
            { path: 'add', component: EditBookComponent },
            { path: 'edit/:id', component: EditBookComponent },
        ]
    },
    { path: 'login', component: LoginComponent },
    { path: '**', redirectTo: '' }
];
