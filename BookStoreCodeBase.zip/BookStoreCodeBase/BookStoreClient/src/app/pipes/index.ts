export {FilterBookPipe} from './filter-books.pipe'
