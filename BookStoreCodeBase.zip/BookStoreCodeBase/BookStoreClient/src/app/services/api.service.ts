import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import 'rxjs/Rx';
import 'rxjs/add/observable/throw';

@Injectable()
export class ApiService {

    headers: HttpHeaders = new HttpHeaders({
    "Content-Type": "application/json",
    Accept: "application/json"
  });

  api_url: string = 'http://localhost:33413/api/BookStore'

  constructor(private http: HttpClient) {
    console.log(this.api_url);
  }

    private formatErrors(error: any) {
        return Observable.throw(error);
    }

  get(path: string, body): Observable<any> {
      return this.http
          .get(`${this.api_url}${path}`, {
              headers: this.headers
          })
          .catch(this.formatErrors);
  }

  post(path: string, body): Observable<any> {
      return this.http
          .post(`${this.api_url}${path}`, JSON.stringify(body), {
              headers: this.headers
          })
          .catch(this.formatErrors);
  }

  put(path: string, body): Observable<any> {
      return this.http
          .put(`${this.api_url}${path}`, JSON.stringify(body), {
              headers: this.headers
          })
          .catch(this.formatErrors);
  }

  delete(path): Observable<any> {
    console.log(path);
      return this.http
          .delete(`${this.api_url}${path}`, { headers: this.headers })
          .catch(this.formatErrors);
  }

  setHeaders(headers) {
    Object.keys(headers).forEach(header =>
      this.headers.set(header, headers[header])
    );
  }
}
