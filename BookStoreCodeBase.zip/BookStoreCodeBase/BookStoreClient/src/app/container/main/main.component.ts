import { Component, OnInit } from '@angular/core';
declare const $: any;

@Component({
    selector: 'main-container',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {

  constructor() { }

    ngOnInit() {
        $(document).foundation();
  }

}
