import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

declare var $: any;

@Component({
    selector: 'auth-container',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

    user = {
        password: '',
        email: ''
    }

    mode: string = 'signin'
    linkText: string = 'Don\'t have an account?'

    constructor(private auth: AuthService, private router: Router) { }

    changeMode() {
        if (this.mode === 'signin') {
            this.mode = 'signup'
            this.linkText = 'Already have an account?'
        } else {
            this.mode = 'signin'
            this.linkText = 'Don\'t have an account?'
        }
    }

    ngOnInit() {
        $(document).foundation();
    }

    authenticate() {
        this.auth.authenticate(this.mode, { user: this.user })
            .subscribe(() => this.router.navigate(['']))
    }

}
