import { Component, OnInit } from '@angular/core';
import { BookService } from '../../services';

@Component({
    selector: 'main-container',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {

    results: boolean = false
    books = []

    constructor(private bookService: BookService) { }

    searchBook(book) {
        this.bookService.getBook({ book })
            .subscribe((data) => {
                this.books = data
                this.results = true
            })
    }

}
