import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgxUploaderModule } from 'ngx-uploader';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';

import {
    AppBarComponent,
    BookComponent,
    SearchBookForm
} from './ui';

import {
    MainComponent,
    ShowBookComponent,
    EditBookComponent,
    HomeComponent,
    LoginComponent
} from './container';

import { FilterBookPipe } from './pipes';

import {
    BookService,
    AuthorService,
    CategoryService,
    PublisherService,
    ApiService,
    AuthService
} from './services';

import { routes } from './';

@NgModule({
  declarations: [
        AppComponent,
        MainComponent,
        AppBarComponent,
        ShowBookComponent,
        BookComponent,
        EditBookComponent,
        HomeComponent,
        SearchBookForm,
        FilterBookPipe,
        LoginComponent
  ],
  imports: [
      BrowserModule,
      FormsModule,
      HttpClientModule,
      RouterModule.forRoot(routes),
      NgxUploaderModule
  ],
    providers: [BookService,
        AuthorService,
        CategoryService,
        PublisherService,
        ApiService,
        AuthService],
  bootstrap: [AppComponent]
})
export class AppModule { }
