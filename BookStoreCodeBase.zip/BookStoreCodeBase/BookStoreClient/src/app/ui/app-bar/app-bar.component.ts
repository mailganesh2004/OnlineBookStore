import { Component, Input, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';

declare var $: any

@Component({
  selector: 'app-bar',
  templateUrl: './app-bar.component.html',
  styleUrls: ['./app-bar.component.css']
})
export class AppBarComponent implements OnInit {

    title: string = 'Book Store'
    isLoggedIn: boolean
    routes = []

    constructor(private auth: AuthService) { }

    ngOnInit() {
        this.isLoggedIn = this.auth.isAuthorized()
        console.log(this.isLoggedIn)
    }

    signout() {
        if (this.isLoggedIn) {
            this.auth.signout()
            this.isLoggedIn = this.auth.isAuthorized()
        }
    }

    onSelectedPage() {
        $('#example-menu').hide()
    }
}
